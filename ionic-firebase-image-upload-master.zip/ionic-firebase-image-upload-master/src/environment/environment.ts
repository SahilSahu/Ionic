export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyDLpMJp5BiFq0luAfzvZQRsQSfKUwwCQgw",
    authDomain: "fir-log-df5ab.firebaseapp.com",
    databaseURL: "https://fir-log-df5ab.firebaseio.com",
    projectId: "firebaselog",
    storageBucket: "firebaselog.appspot.com",
    messagingSenderId: "1098056656045"
  }
}
